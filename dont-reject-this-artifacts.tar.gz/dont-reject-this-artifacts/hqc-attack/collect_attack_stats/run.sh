#!/usr/bin/env bash

../target/release/gather_data_rayon ../attack-hybrid "$1"